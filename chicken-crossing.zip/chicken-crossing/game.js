(function(){
var M=THREE.MathUtils,minT=-8,maxT=8,perRow=17,TS=42;
function rnd(a){return a[Math.floor(Math.random()*a.length)];}
function bx(p,w,d,h,c,x,y,z,cast){
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,d,h),new THREE.MeshLambertMaterial({color:c,flatShading:true}));
  m.position.set(x,y,z);if(cast){m.castShadow=true;m.receiveShadow=true;}p.add(m);return m;
}

/* ---------- Player: the superhero chicken (game axes: x right, y forward, z up) ---------- */
function Chicken(){
  var g=new THREE.Group(),S=9,RED=0xd8333a,GOLD=0xffd23a;
  function K(w,h,d,c,x,y,z){bx(g,w*S,d*S,h*S,c,x*S,z*S,y*S,true);}
  K(1.5,1.4,1.5,0x2f6fd8,0,1.35,0);                 // suit body
  K(1.5,1.1,1.5,0xf4f1e8,0,2.55,0);                 // head
  K(0.5,0.32,0.6,0xf0922a,0,2.45,1.05);             // beak
  K(1.58,0.34,1.58,RED,0,2.7,0);                    // mask
  K(0.28,0.16,0.04,0xffffff,0.42,2.72,0.8);K(0.28,0.16,0.04,0xffffff,-0.42,2.72,0.8);
  K(0.2,0.35,0.7,RED,0,3.25,0);                     // crest
  K(0.16,0.75,0.95,0x2559b0,0.83,1.4,0);K(0.16,0.75,0.95,0x2559b0,-0.83,1.4,0);
  K(0.2,0.25,0.97,RED,0.83,1.1,0);K(0.2,0.25,0.97,RED,-0.83,1.1,0); // gloves
  K(1.7,0.2,0.35,RED,0,2.05,-0.7);                  // cape collar
  K(1.5,0.9,0.14,RED,0,1.55,-0.82);                 // cape upper
  K(1.85,0.9,0.14,0xb82a30,0,0.7,-0.9);             // cape flare
  K(0.55,0.55,0.05,GOLD,0,1.55,0.78);K(0.35,0.35,0.06,RED,0,1.55,0.8); // emblem
  K(1.54,0.2,1.54,RED,0,0.75,0);K(1.56,0.18,1.56,GOLD,0,0.95,0);       // trunks, belt
  [-0.35,0.35].forEach(function(x){K(0.2,0.4,0.2,RED,x,0.3,0);K(0.22,0.08,0.22,GOLD,x,0.52,0);K(0.52,0.12,0.62,RED,x,0.06,0.1);});
  return g;
}
var player=new THREE.Group(),chicken=new THREE.Group();player.add(chicken);
var BASE=1.5;

/* ---------- World pieces ---------- */
function Camera(){
  var c=new THREE.OrthographicCamera(-1,1,1,-1,100,900);
  c.up.set(0,0,1);c.position.set(300,-300,300);c.lookAt(0,0,0);return c;
}
function Grass(i){
  var g=new THREE.Group();g.position.y=i*TS;
  var m=bx(g,perRow*TS,TS,3,0xbaf455,0,0,0);m.receiveShadow=true;
  bx(g,perRow*TS,TS,3,0x99c846,-perRow*TS,0,0);bx(g,perRow*TS,TS,3,0x99c846,perRow*TS,0,0);
  return g;
}
function Road(i){
  var g=new THREE.Group();g.position.y=i*TS;
  var m=bx(g,perRow*TS,TS,1,0x454a59,0,0,-1);m.receiveShadow=true;
  bx(g,perRow*TS,TS,1,0x393d49,-perRow*TS,0,-1);bx(g,perRow*TS,TS,1,0x393d49,perRow*TS,0,-1);
  for(var k=minT;k<=maxT;k++)bx(g,18,3,0.5,0x6a7083,k*TS,-TS/2+1.5,-0.4);
  return g;
}
function Tree(t,h){
  var g=new THREE.Group();g.position.x=t*TS;
  bx(g,15,15,20,0x4d2926,0,0,10);
  bx(g,30,30,h,0x7aa21d,0,0,h/2+20,true);return g;
}
function Wheel(x){return bx(new THREE.Group(),12,33,12,0x333333,x,0,6);}
function wheel(g,x){bx(g,12,33,12,0x333333,x,0,6);}
function Car(t,dir,color){
  var g=new THREE.Group();g.position.x=t*TS;if(!dir)g.rotation.z=Math.PI;
  bx(g,60,30,15,color,0,0,12,true);
  bx(g,33,24,12,0xdddddd,-6,0,25.5,true);
  bx(g,1,22,9,0x2b3345,10.7,0,25.5);bx(g,1,22,9,0x2b3345,-22.7,0,25.5);
  bx(g,22,0.6,8,0x2b3345,-6,12.1,25.5);bx(g,22,0.6,8,0x2b3345,-6,-12.1,25.5);
  wheel(g,18);wheel(g,-18);return g;
}
function Truck(t,dir,color){
  var g=new THREE.Group();g.position.x=t*TS;if(!dir)g.rotation.z=Math.PI;
  bx(g,70,35,35,0xb4c6fc,-15,0,25,true);
  bx(g,30,30,30,color,35,0,20,true);
  bx(g,1,26,12,0x2b3345,50.3,0,27);bx(g,14,0.6,10,0x2b3345,38,15.1,27);bx(g,14,0.6,10,0x2b3345,38,-15.1,27);
  wheel(g,37);wheel(g,5);wheel(g,-35);return g;
}

/* ---------- Map & rules ---------- */
var COLORS=[0xd8333a,0xf0c030,0x4aa84a,0x3a7bd8,0xe07a2a];
var metadata=[],map=new THREE.Group(),queue=[],pos={row:0,tile:0},dead=false,best=0;
try{best=+localStorage.getItem('chickenBest')||0;}catch(e){}

function laneMeta(type){
  var dir=rnd([true,false]),speed=rnd([125,156,188]),used={},n=type==='car'?3:2,span=type==='car'?1:2,v=[];
  for(var i=0;i<n;i++){
    var t,tries=0;
    do{t=M.randInt(minT,maxT);tries++;}while(used[t]&&tries<40);
    for(var k=-span;k<=span;k++)used[t+k]=true;
    v.push({initialTileIndex:t,color:rnd(COLORS)});
  }
  return {type:type,direction:dir,speed:speed,vehicles:v};
}
function forestMeta(){
  var used={},trees=[];
  for(var i=0;i<4;i++){var t;do{t=M.randInt(minT,maxT);}while(used[t]);used[t]=true;trees.push({tileIndex:t,height:rnd([20,45,60])});}
  return {type:'forest',trees:trees};
}
function genRow(){var t=rnd(['car','truck','forest','forest']);return t==='forest'?forestMeta():laneMeta(t);}

function addRows(){
  var start=metadata.length,rows=[];
  for(var i=0;i<20;i++)rows.push(genRow());
  metadata.push.apply(metadata,rows);
  rows.forEach(function(d,i){
    var idx=start+i+1,row;
    if(d.type==='forest'){row=Grass(idx);d.trees.forEach(function(t){row.add(Tree(t.tileIndex,t.height));});}
    else{row=Road(idx);d.vehicles.forEach(function(v){v.ref=(d.type==='car'?Car:Truck)(v.initialTileIndex,d.direction,v.color);row.add(v.ref);});}
    map.add(row);
  });
}
function initMap(){
  metadata.length=0;map.remove.apply(map,map.children.slice());
  for(var r=0;r>-10;r--)map.add(Grass(r));
  addRows();
}

function finalPos(moves){
  var r=pos.row,t=pos.tile;
  moves.forEach(function(m){if(m==='forward')r++;if(m==='backward')r--;if(m==='left')t--;if(m==='right')t++;});
  return {r:r,t:t};
}
function validMove(moves){
  var p=finalPos(moves);
  if(p.r===-1||p.t<minT||p.t>maxT)return false;
  var row=metadata[p.r-1];
  if(row&&row.type==='forest'&&row.trees.some(function(x){return x.tileIndex===p.t;}))return false;
  return true;
}
function queueMove(d){
  if(dead||inMenu||queue.length>=3)return;
  if(validMove(queue.concat(d)))queue.push(d);
}

/* ---------- UI ---------- */
var scoreEl=document.getElementById('score'),bestEl=document.getElementById('best'),resEl=document.getElementById('result-container');
function showBest(){bestEl.textContent='BEST '+best;}
function stepDone(){
  var d=queue.shift();
  if(d==='forward')pos.row++;if(d==='backward')pos.row--;if(d==='left')pos.tile--;if(d==='right')pos.tile++;
  if(pos.row>metadata.length-10)addRows();
  scoreEl.textContent=pos.row;
}
function die(){
  if(dead)return;dead=true;queue.length=0;
  chicken.scale.z=0.15;chicken.position.z=BASE;
  if(pos.row>best){best=pos.row;try{localStorage.setItem('chickenBest',best);}catch(e){}}
  showBest();
  document.getElementById('final-score').textContent=pos.row;
  document.getElementById('final-best').textContent=best;
  resEl.style.display='flex';
}
function initGame(){
  dead=false;queue.length=0;pos.row=0;pos.tile=0;
  player.position.set(0,0,0);chicken.position.z=BASE;chicken.rotation.z=0;chicken.scale.z=1;
  initMap();scoreEl.textContent='0';showBest();resEl.style.display='none';
}

/* ---------- Scene ---------- */
var canvas=document.getElementById('game');
var renderer=new THREE.WebGLRenderer({canvas:canvas,alpha:true,antialias:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.shadowMap.enabled=true;
var scene=new THREE.Scene();scene.add(player);scene.add(map);
scene.add(new THREE.AmbientLight(0xffffff,0.8));
var sun=new THREE.DirectionalLight(0xffffff,0.8);
sun.position.set(-100,-100,200);sun.up.set(0,0,1);sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.up.set(0,0,1);
sun.shadow.camera.left=-400;sun.shadow.camera.right=400;sun.shadow.camera.top=400;sun.shadow.camera.bottom=-400;
sun.shadow.camera.near=50;sun.shadow.camera.far=400;
sun.target=player;player.add(sun);
var camera=Camera();player.add(camera);
function resize(){
  var w=innerWidth,h=innerHeight,r=w/h,size=300,vw=r<1?size:size*r,vh=r<1?size/r:size;
  camera.left=-vw/2;camera.right=vw/2;camera.top=vh/2;camera.bottom=-vh/2;camera.updateProjectionMatrix();
  renderer.setSize(w,h,false);
}
addEventListener('resize',resize);resize();

/* ---------- Animation ---------- */
var moveClock=new THREE.Clock(false),clock=new THREE.Clock();
function animatePlayer(){
  if(!queue.length||dead)return;
  if(!moveClock.running)moveClock.start();
  var p=Math.min(1,moveClock.getElapsedTime()/0.2),m=queue[0];
  var sx=pos.tile*TS,sy=pos.row*TS,ex=sx,ey=sy,rot=0;
  if(m==='left'){ex-=TS;rot=Math.PI/2;}
  if(m==='right'){ex+=TS;rot=-Math.PI/2;}
  if(m==='forward'){ey+=TS;rot=0;}
  if(m==='backward'){ey-=TS;rot=Math.PI;}
  player.position.x=M.lerp(sx,ex,p);player.position.y=M.lerp(sy,ey,p);
  chicken.position.z=BASE+Math.sin(p*Math.PI)*8;
  var cur=chicken.rotation.z,diff=((rot-cur+Math.PI*3)%(Math.PI*2))-Math.PI;
  chicken.rotation.z=cur+diff*0.35;
  if(p>=1){stepDone();moveClock.stop();chicken.rotation.z=rot;}
}
function animateVehicles(){
  var dt=Math.min(clock.getDelta(),0.05),a=(minT-2)*TS,b=(maxT+2)*TS;
  metadata.forEach(function(d,i){
    if(d.type==='forest'||Math.abs(i+1-pos.row)>30)return;
    d.vehicles.forEach(function(v){
      var x=v.ref.position.x;
      v.ref.position.x=d.direction?(x>b?a:x+d.speed*dt):(x<a?b:x-d.speed*dt);
    });
  });
}
function hitTest(){
  if(dead)return;
  var idx=Math.round(player.position.y/TS),row=metadata[idx-1];
  if(!row||row.type==='forest')return;
  var px=player.position.x,py=player.position.y;
  var pb=new THREE.Box3(new THREE.Vector3(px-6,py-6,0),new THREE.Vector3(px+6,py+6,25)),vb=new THREE.Box3();
  for(var i=0;i<row.vehicles.length;i++){
    vb.setFromObject(row.vehicles[i].ref);
    if(pb.intersectsBox(vb)){die();return;}
  }
}
renderer.setAnimationLoop(function(){animateVehicles();animatePlayer();hitTest();renderer.render(scene,camera);});

/* ---------- Input ---------- */
['forward','backward','left','right'].forEach(function(d){document.getElementById(d).addEventListener('click',function(){queueMove(d);});});
document.getElementById('retry').addEventListener('click',initGame);
var KEYS={ArrowUp:'forward',w:'forward',W:'forward',ArrowDown:'backward',s:'backward',S:'backward',ArrowLeft:'left',a:'left',A:'left',ArrowRight:'right',d:'right',D:'right'};
addEventListener('keydown',function(e){
  if(dead&&(e.key==='Enter'||e.key===' ')){initGame();return;}
  if(KEYS[e.key]){e.preventDefault();queueMove(KEYS[e.key]);}
});
var sx0=0,sy0=0;
addEventListener('touchstart',function(e){if(e.target.closest('button,#joy'))return;sx0=e.touches[0].clientX;sy0=e.touches[0].clientY;},{passive:true});
addEventListener('touchend',function(e){
  if(e.target.closest('button,#joy'))return;
  var t=e.changedTouches[0],dx=t.clientX-sx0,dy=t.clientY-sy0;
  if(Math.abs(dx)<20&&Math.abs(dy)<20)return queueMove('forward');
  if(Math.abs(dx)>Math.abs(dy))queueMove(dx<0?'left':'right');else queueMove(dy<0?'forward':'backward');
},{passive:true});

/* ---------- Costumes + start menu ---------- */
var inMenu=true,sel=0,$=function(id){return document.getElementById(id);};
try{sel=+localStorage.getItem('chickenCostume')||0;}catch(e){}
var RD=0xd8333a,ORG=0xf0922a,LEG=0xd9702a,EYE=0x1a1216,GD=0xffd23a;
function box(g,w,h,d,c,x,y,z,o){o=o||{};
  var m=o.basic?new THREE.MeshBasicMaterial({color:c}):new THREE.MeshLambertMaterial({color:c,flatShading:true});
  if(o.t){m.transparent=true;m.opacity=o.t;}
  var b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);b.position.set(x,y,z);b.rotation.set(o.rx||0,o.ry||0,o.rz||0);g.add(b);}
function base(g,P){
  box(g,1.5,1.4,1.5,P.body,0,1.35,0);box(g,1.5,1.1,1.5,P.head,0,2.55,0);box(g,0.5,0.32,0.6,ORG,0,2.45,1.05);
  if(!P.noWattle)box(g,0.3,0.4,0.25,RD,0,2.1,0.85);
  if(!P.noEyes){box(g,0.12,0.2,0.06,EYE,0.42,2.7,0.76);box(g,0.12,0.2,0.06,EYE,-0.42,2.7,0.76);}
  box(g,0.16,0.75,0.95,P.wing,0.83,1.4,0);box(g,0.16,0.75,0.95,P.wing,-0.83,1.4,0);
  box(g,0.5,0.8,0.4,P.wing,0,1.9,-0.9,{rx:-0.35});
  [-0.35,0.35].forEach(function(x){box(g,0.12,0.5,0.12,LEG,x,0.4,0);box(g,0.5,0.1,0.6,LEG,x,0.05,0.1);});
}
var defs=[
{name:'Superhero',bg:'#2a2f7a',build:function(g){
  base(g,{body:0x2f6fd8,head:0xf4f1e8,wing:0x2559b0,noWattle:true,noEyes:true});
  box(g,1.58,0.34,1.58,RD,0,2.7,0);[-0.42,0.42].forEach(function(x){box(g,0.28,0.16,0.04,0xffffff,x,2.72,0.8);});
  box(g,1.7,0.2,0.35,RD,0,2.05,-0.7);box(g,1.5,0.9,0.14,RD,0,1.55,-0.82);box(g,1.85,0.9,0.14,0xb82a30,0,0.7,-0.9);
  box(g,0.75,0.75,0.05,GD,0,1.55,0.78,{rz:0.785});box(g,0.5,0.5,0.06,RD,0,1.55,0.8,{rz:0.785});
  box(g,1.54,0.2,1.54,RD,0,0.75,0);box(g,1.56,0.18,1.56,GD,0,0.95,0);box(g,0.3,0.22,0.06,GD,0,0.95,0.8);
  [-1,1].forEach(function(s){box(g,0.2,0.25,0.97,RD,s*0.83,1.1,0);});
  [-0.35,0.35].forEach(function(x){box(g,0.2,0.4,0.2,RD,x,0.3,0);box(g,0.22,0.08,0.22,GD,x,0.52,0);box(g,0.52,0.12,0.62,RD,x,0.06,0.1);});
}},
{name:'Pirate',bg:'#2f6a9a',build:function(g){
  base(g,{body:0xf4f1e8,head:0xf4f1e8,wing:0xdcd6c6});
  box(g,1.54,0.22,1.54,0x1f3a6b,0,0.95,0);box(g,1.54,0.22,1.54,0x1f3a6b,0,1.55,0);
  box(g,1.95,0.15,1.95,0x16161d,0,3.2,0);box(g,1.4,0.35,1.4,0x16161d,0,3.45,0);box(g,0.3,0.22,0.05,0xffffff,0,3.45,0.72);
  box(g,0.3,0.3,0.06,0x111116,-0.42,2.7,0.78);box(g,0.1,0.2,0.1,0xffc83a,0.78,2.35,0.1);
}},
{name:'Astronaut',bg:'#1b1f4a',build:function(g){
  base(g,{body:0xeceff5,head:0xeceff5,wing:0xc9ced9});
  box(g,1.85,1.45,1.85,0x7fc8ff,0,2.6,0,{t:0.28});box(g,1.9,0.18,1.9,0xb8bfcc,0,1.95,0);box(g,0.9,1.1,0.4,0x9aa2b2,0,1.5,-0.95);
  box(g,0.7,0.5,0.06,0x2c3a55,0,1.6,0.78);box(g,0.12,0.12,0.04,0xe84a4a,-0.18,1.6,0.82);box(g,0.12,0.12,0.04,0x4adf7a,0.18,1.6,0.82);
  box(g,1.54,0.15,1.54,0xf07a2a,0,0.85,0);box(g,0.06,0.45,0.06,0xb8bfcc,0.6,3.55,0);box(g,0.14,0.14,0.14,0xe84a4a,0.6,3.85,0);
}},
{name:'Wizard',bg:'#3b2a6b',build:function(g){
  base(g,{body:0x5a3fa0,head:0xf4f1e8,wing:0x4a3290,noWattle:true});
  [[-0.4,1.75,0.22],[0.35,1.35,0.16],[-0.1,1.05,0.12],[0.4,1.9,0.12]].forEach(function(s){box(g,s[2],s[2],0.05,GD,s[0],s[1],0.77);});
  box(g,1.1,0.5,0.25,0xffffff,0,2.1,0.88);box(g,1.95,0.15,1.95,0x3a2a80,0,3.12,0);
  box(g,1.4,0.5,1.4,0x4a3aa0,0,3.45,0);box(g,1.0,0.5,1.0,0x4a3aa0,0,3.95,0);box(g,0.65,0.5,0.65,0x4a3aa0,0,4.45,0);box(g,0.35,0.4,0.35,0x4a3aa0,0.1,4.9,0,{rz:-0.3});
  box(g,0.1,2.8,0.1,0x7a4a22,1.2,1.6,0.5);box(g,0.3,0.3,0.3,0x7ff0ff,1.2,3.1,0.5,{basic:true});
}},
{name:'Ninja',bg:'#5a1f2b',build:function(g){
  base(g,{body:0x23232e,head:0x23232e,wing:0x34344a,noWattle:true,noEyes:true});
  box(g,1.2,0.3,0.04,0xf0d9b8,0,2.7,0.77);
  [-0.33,0.33].forEach(function(x){box(g,0.2,0.14,0.04,0xffffff,x,2.72,0.8);box(g,0.08,0.12,0.04,EYE,x,2.72,0.82);});
  box(g,1.58,0.2,1.58,RD,0,2.98,0);box(g,0.18,0.55,0.1,RD,0.2,2.75,-0.9,{rx:0.4});box(g,0.18,0.55,0.1,RD,-0.2,2.65,-0.95,{rx:0.7});
  box(g,1.54,0.18,1.54,RD,0,1.15,0);box(g,0.08,1.9,0.14,0xcfd6df,0,1.9,-0.85,{rz:0.7});box(g,0.12,0.5,0.2,0x5a3a22,-0.72,2.7,-0.85,{rz:0.7});
  box(g,0.35,0.07,0.04,0xcfd6df,0,1.6,0.78,{rz:0.78});box(g,0.35,0.07,0.04,0xcfd6df,0,1.6,0.78,{rz:-0.78});
}},
{name:'Chef',bg:'#8a4a3a',build:function(g){
  base(g,{body:0xffffff,head:0xf6f3ea,wing:0xe8e4d6,noWattle:true});
  box(g,1.4,0.35,1.4,0xf2f2f2,0,3.2,0);box(g,1.75,0.7,1.75,0xfafafa,0,3.75,0);box(g,1.3,0.3,1.3,0xfafafa,0,4.25,0);
  box(g,1.54,0.9,0.1,0x2f6fb5,0,1.2,0.77);box(g,0.45,0.3,0.05,0x255a96,0,1.05,0.84);box(g,0.8,0.16,0.2,0x2a1d14,0,2.2,0.84);
  box(g,0.08,1.2,0.08,0x7a4a22,-1.2,1.3,0.5);box(g,0.4,0.5,0.06,0xcfd6df,-1.2,2.1,0.5);
}},
{name:'Knight',bg:'#3d5a7a',build:function(g){
  base(g,{body:0xb8c0cc,head:0xb8c0cc,wing:0x8f98a6,noWattle:true,noEyes:true});
  box(g,1.62,1.2,1.62,0xc9d0da,0,2.6,0);box(g,1.3,0.15,0.04,0x22262e,0,2.7,0.82);box(g,1.2,0.15,1.2,0xc9d0da,0,3.28,0);box(g,0.2,0.6,0.9,RD,0,3.6,-0.1);
  box(g,0.4,0.4,0.05,RD,0,1.6,0.77);box(g,1.54,0.15,1.54,0x7a4a22,0,0.95,0);
  box(g,0.12,1.0,0.8,0x2f5fb5,-1.0,1.4,0.2);box(g,0.14,0.7,0.12,GD,-1.0,1.4,0.2);box(g,0.14,0.12,0.5,GD,-1.0,1.5,0.2);
  box(g,0.08,1.6,0.14,0xe3e8ee,1.2,1.8,0.5);box(g,0.5,0.1,0.14,0x7a4a22,1.2,0.98,0.5);box(g,0.1,0.3,0.1,0x7a4a22,1.2,0.78,0.5);
}},
{name:'Cowboy',bg:'#b8742f',build:function(g){
  base(g,{body:0xf4f1e8,head:0xf4f1e8,wing:0xdcd6c6,noWattle:true});
  box(g,0.6,0.9,0.1,0x8a5a2a,-0.4,1.5,0.77);box(g,0.6,0.9,0.1,0x8a5a2a,0.4,1.5,0.77);box(g,1.1,0.3,0.14,RD,0,1.95,0.8);
  box(g,0.25,0.25,0.05,GD,0.45,1.65,0.84,{rz:0.785});
  box(g,2.15,0.12,1.95,0x8a5a2a,0,3.15,0);box(g,1.4,0.55,1.4,0x8a5a2a,0,3.45,0);box(g,1.44,0.14,1.44,0x3a2a1a,0,3.28,0);
  [-0.35,0.35].forEach(function(x){box(g,0.2,0.35,0.2,0x6a4222,x,0.3,0);box(g,0.12,0.12,0.12,GD,x,0.15,-0.25);});
}},
{name:'Viking',bg:'#2e4a56',build:function(g){
  base(g,{body:0xf4f1e8,head:0xf4f1e8,wing:0xdcd6c6,noWattle:true});
  box(g,1.56,0.6,1.56,0x7a4a22,0,1.0,0);box(g,1.6,0.15,1.6,0xffffff,0,1.7,0);box(g,1.6,0.4,1.6,0x9aa2b2,0,3.1,0);box(g,1.2,0.3,1.2,0x9aa2b2,0,3.45,0);
  [-1,1].forEach(function(s){box(g,0.2,0.4,0.2,0xf2e6c2,s*0.85,3.1,0);box(g,0.2,0.4,0.2,0xf2e6c2,s*1.0,3.45,0);box(g,0.15,0.3,0.15,0xf2e6c2,s*1.1,3.8,0);box(g,0.15,0.5,0.15,0xc8501e,s*0.3,1.65,0.9);});
  box(g,0.9,0.5,0.25,0xc8501e,0,2.05,0.88);box(g,0.12,0.9,0.9,0xb5392e,-1.0,1.4,0.2);box(g,0.14,0.25,0.25,0xcfd6df,-1.0,1.4,0.2);
  box(g,0.1,1.8,0.1,0x7a4a22,1.2,1.6,0.5);box(g,0.5,0.45,0.1,0xcfd6df,1.35,2.3,0.5);
}},
{name:'Pharaoh',bg:'#7a5a1f',build:function(g){
  base(g,{body:0xf4f1e8,head:0xf4f1e8,wing:0xdcd6c6,noWattle:true});
  box(g,1.62,0.3,1.62,0xffc83a,0,1.95,0);box(g,0.3,0.3,0.05,0x2f8fd8,0,1.95,0.82);box(g,0.3,0.3,0.05,0x2fb8a8,0,1.55,0.78);
  box(g,1.66,0.3,1.66,0x2f6fd8,0,3.2,0);box(g,1.68,0.1,1.68,0xffc83a,0,3.2,0);
  [-1,1].forEach(function(s){box(g,0.3,1.3,0.9,0x2f6fd8,s*0.92,2.45,0.1);box(g,0.32,0.1,0.92,0xffc83a,s*0.92,2.5,0.1);});
  box(g,1.2,1.5,0.3,0x2f6fd8,0,2.4,-0.95);box(g,0.2,0.4,0.15,0xffc83a,0,3.55,0.7);
  box(g,0.2,0.6,0.15,0x2f6fd8,0,1.8,0.85);box(g,0.2,0.12,0.15,0xffc83a,0,1.45,0.85);
  box(g,0.1,2.4,0.1,0xffc83a,1.2,1.4,0.5);box(g,0.4,0.1,0.1,0xffc83a,1.05,2.6,0.5);
}}
];
if(sel<0||sel>=defs.length)sel=0;
/* model axes (y up, z front) -> game axes (z up, y forward) */
function buildCostume(i){
  var m=new THREE.Group();defs[i].build(m);m.rotation.x=Math.PI/2;
  var h=new THREE.Group();h.rotation.z=Math.PI;h.scale.setScalar(8);h.add(m);
  h.traverse(function(o){if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});return h;
}
function setCostume(i){chicken.remove.apply(chicken,chicken.children.slice());chicken.add(buildCostume(i));}

/* preview scene */
var pr=new THREE.WebGLRenderer({canvas:$('pv'),alpha:true,antialias:true});
pr.setPixelRatio(Math.min(devicePixelRatio||1,2));pr.setSize(480,480,false);
var ps=new THREE.Scene(),pc=new THREE.OrthographicCamera(-46,46,46,-46,1,800);
pc.up.set(0,0,1);pc.position.set(160,170,120);pc.lookAt(0,0,22);
ps.add(new THREE.AmbientLight(0xffffff,0.85));
var plt=new THREE.DirectionalLight(0xffffff,0.7);plt.position.set(100,150,200);ps.add(plt);
bx(ps,50,50,4,0x7ac74a,0,0,-2);
var pw=new THREE.Group();ps.add(pw);
var pt=0;
(function tick(){requestAnimationFrame(tick);if(!inMenu)return;pt+=0.03;pw.rotation.z=Math.sin(pt)*0.6;pw.position.z=Math.abs(Math.sin(pt*2))*2;pr.render(ps,pc);})();

var menu=$('menu'),chips=[];
function view(v){menu.setAttribute('data-view',v);}
function pick(i){
  sel=(i+defs.length)%defs.length;
  try{localStorage.setItem('chickenCostume',sel);}catch(e){}
  $('cosname').textContent=defs[sel].name;
  chips.forEach(function(c,k){c.className='chip'+(k===sel?' on':'');});
  pw.remove.apply(pw,pw.children.slice());pw.add(buildCostume(sel));
}
defs.forEach(function(d,i){var c=document.createElement('button');c.textContent=d.name[0];c.title=d.name;c.style.background=d.bg;c.onclick=function(){pick(i);};$('cosgrid').appendChild(c);chips.push(c);});
function isFull(){return document.fullscreenElement||document.webkitFullscreenElement;}
function goFull(){var e=document.documentElement,f=e.requestFullscreen||e.webkitRequestFullscreen;if(f&&!isFull()){try{var p=f.call(e);if(p&&p.catch)p.catch(function(){});}catch(x){}}}
function exitFull(){var f=document.exitFullscreen||document.webkitExitFullscreen;if(f&&isFull()){try{var p=f.call(document);if(p&&p.catch)p.catch(function(){});}catch(x){}}}
function toggleFull(){if(isFull())exitFull();else goFull();}
function startGame(){if(!inMenu)return;inMenu=false;menu.style.display='none';$('pausebtn').style.display='block';goFull();setCostume(sel);initGame();}
function toMenu(){initGame();inMenu=true;menu.style.display='flex';$('pausebtn').style.display='none';view('main');}
$('fs').onclick=toggleFull;$('pausebtn').onclick=toMenu;
['fullscreenchange','webkitfullscreenchange','orientationchange'].forEach(function(ev){document.addEventListener(ev,function(){setTimeout(resize,100);});});
$('m-start').onclick=startGame;
$('m-cos').onclick=function(){view('cos');};
$('m-opt').onclick=function(){view('opt');};
$('m-score').onclick=function(){$('sb').textContent=best;view('score');};
Array.prototype.forEach.call(document.querySelectorAll('.back'),function(b){b.onclick=function(){view('main');};});
$('c-prev').onclick=function(){pick(sel-1);};$('c-next').onclick=function(){pick(sel+1);};
var ctl=matchMedia('(pointer:coarse)').matches?0:2,shOn=true,CTL=['Joystick','D-pad','Off'];
function applyCtl(){$('joy').style.display=ctl===0?'block':'none';$('controls').style.display=ctl===1?'flex':'none';$('o-pad').textContent='Controls: '+CTL[ctl];}
applyCtl();
$('o-pad').onclick=function(){ctl=(ctl+1)%3;applyCtl();};
/* joystick */
var jb=$('joy'),jk=$('knob'),jd=null,jl=null,jid=null;
function jmove(e){
  var r=jb.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.hypot(dx,dy),R=r.width/2-8;
  if(m>R){dx*=R/m;dy*=R/m;m=R;}
  jk.style.transform='translate('+dx+'px,'+dy+'px)';
  jd=m<R*0.35?null:(Math.abs(dx)>Math.abs(dy)?(dx<0?'left':'right'):(dy<0?'forward':'backward'));
  if(jd&&jd!==jl&&!queue.length)queueMove(jd);
  jl=jd;
}
jb.addEventListener('pointerdown',function(e){jid=e.pointerId;jb.setPointerCapture(jid);jmove(e);e.preventDefault();});
jb.addEventListener('pointermove',function(e){if(e.pointerId===jid)jmove(e);});
function jend(e){if(e.pointerId!==jid)return;jid=null;jd=null;jl=null;jk.style.transform='';}
jb.addEventListener('pointerup',jend);jb.addEventListener('pointercancel',jend);
setInterval(function(){if(jd&&!queue.length)queueMove(jd);},60);
/* rotate screen */
var ROT=['auto','landscape','portrait'],ri=0;
function rotLabel(t){$('o-rot').textContent='Rotate: '+(t||ROT[ri].charAt(0).toUpperCase()+ROT[ri].slice(1));}
function rotMsg(t){rotLabel(t);setTimeout(function(){rotLabel();},1800);}
function applyRot(){
  var so=screen.orientation,m=ROT[ri];
  if(!so||!so.lock){rotMsg('Not supported');return;}
  if(m==='auto'){try{so.unlock();}catch(e){}return;}
  so.lock(m).catch(function(){goFull();setTimeout(function(){so.lock(m).catch(function(){rotMsg('Turn your phone');});},400);});
}
function cycleRot(){ri=(ri+1)%3;rotLabel();applyRot();}
$('o-rot').onclick=cycleRot;$('rot').onclick=cycleRot;
$('o-shadow').onclick=function(){shOn=!shOn;sun.castShadow=shOn;this.textContent='Shadows: '+(shOn?'ON':'OFF');};
$('tomenu').onclick=toMenu;
addEventListener('keydown',function(e){if(inMenu&&e.key==='Enter')startGame();if(e.key==='f'||e.key==='F')toggleFull();});
pick(sel);setCostume(sel);initGame();
})();
